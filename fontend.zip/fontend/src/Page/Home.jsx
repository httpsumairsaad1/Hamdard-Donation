import React from 'react'
import HeroSection from '../components/HeroSection/HeroSection'
import ProjectCard from '../components/ProjectCards/ProjectCard'
import FeaturesPost from '../components/FeaturesPost/FeaturesPost'

const Home = () => {
  return (
    <>
    <HeroSection />
    <ProjectCard />
    <FeaturesPost />
    </>
  )
}

export default Home