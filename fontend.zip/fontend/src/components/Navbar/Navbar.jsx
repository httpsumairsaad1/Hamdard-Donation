import React from 'react'
import './style.css'
import { Link } from 'react-router-dom'
const Navbar = () => {
  return (
    <>
    <div className={'toplogo'}>
    <div className={'logobackorange'}>
    </div>
    <div className={'logo'}>
        <div className={'logo-1'}>
            <div className={'hamdard'}>
                Hamdard
            </div>
            <svg id="1:3057/0:1370" className={'global-charity'}></svg>
        </div>
    </div>
</div>

<div className={'languagebutton'}>
    <svg id="0:1378" className={'vector'}></svg>
    <div className={'en'}>
        EN
    </div>
</div>

<div className={'loginbutton'}>
    <div className={'loginbuttonshape'}>
    </div>
    <div className={'login'}>
        Login
    </div>
</div>

<div className={'joinbutton'}>
    <div className={'joinbuttonshape'}>
    </div>
    <div className={'join-as-donor'}>
        Join as Donor
    </div>
</div>
</>
  )
}

export default Navbar